﻿using System;

namespace Animal
{
    class Program
    {
        static void Main(String[] args)
        {

        }
    }
}
