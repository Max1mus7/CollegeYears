﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chessboard
{
    class Program
    {
        public static void Main(String[] args)
        {

        }
    }
}
