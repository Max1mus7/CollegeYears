<?php

namespace App\Http\Controllers;

use App\Models\UserModel;
use Illuminate\Http\Request;
use App\Services\Business\SecurityService;
class LoginController extends Controller
{
    public function index(Request $request)
    {
        
        $credentials = new UserModel($request->input('username'), $request->input('password'));
        $serviceLogin = new SecurityService();
        $isValid = $serviceLogin->login($credentials);
        $data = ['credentials' => $credentials];
        if($isValid)
        {
            return View('loginPassed2')->with($data);
        }
        else
        {
            return View('loginFailed');
        }
    }
}
