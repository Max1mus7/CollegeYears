<?php
namespace App\Services\Business;

use App\Services\Data\SecurityDAO;

use App\Models\UserModel;

use App\Services\Data;


class SecurityService
{
     private $DAO;
     
     public function __construct()
     {
         $this->DAO = new SecurityDAO();
     }
     
     public function login($credentials)
     {
         return $this->DAO->findByUser($credentials);
     }
}

?>