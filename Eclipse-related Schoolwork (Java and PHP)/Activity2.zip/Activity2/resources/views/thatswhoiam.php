<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=Cp1252">
<title>Insert title here</title>
</head>
    <body>
    <h2> Hello!</h2>
	<?php echo $firstName . " " . $lastName; ?>
	<br>
	<a href="askme">Go Again</a>
    

    </body>
</html>